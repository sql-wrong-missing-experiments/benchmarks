###############################################################
# HR-SQL 2.0
# Python script for:
#   - Database Filename   : fib
#   - This Python Filename: script.py
#   - ODBC Connection     : postgresql
#   - RDBMS               : PostgreSQL
#   - Prolog System       : swi
#
# Run this script with the ODBC connection defined already at 
#   the OS level and the database system up and running.
###############################################################

# Importing modules:
import pyodbc
import sys

# Try to open the ODBC connection:
try:
  conn = pyodbc.connect("DSN=postgresql")
except:
  print "Error opening connection 'postgresql'."
  sys.exit()

# Cursor definition:
cursor=conn.cursor()

# Creating RN\RN' Tables:
# Creating RN' Temporary Tables:

# Dropping RN' Temporary Tables:

# Commit changes:
conn.commit()

# If successful, print Success:
print "Success."
