   --------------------------------
  | DES INSTALLATION (quick guide) |
   --------------------------------

================================================
Windows Binary Distribution with ACIDE GUI
================================================
- Double-click on des_acide.jar for starting the 
  ACIDE GUI

================================================
Windows Binary Distribution
================================================
- Double-click on deswin.exe for starting the Windows
  application
- Execute des.exe for starting the console application

================================================
Linux/MacOSX Binary Distribution with ACIDE GUI
================================================
- Add execute permission to file des, typically with:
  chmod +x ./bin/des
  or from the file explorer.
- Start ACIDE from a terminal with:
  java -jar des_acide.jar  

================================================
Linux/MacOSX Binary Distribution
================================================
- Add execute persmission to file des, typically with:
  chmod +x ./des
  or from the file explorer.
- Start ./des in a terminal from its installation path

================================================
Windows Source Distributions
================================================
1. Create a shortcut in the desktop for running the Prolog 
   interpreter of your choice. 
2. Modify the start directory in the "Properties" dialog box 
   of the shortcut to the installation directory for DES. 
   This allows the system to consult the needed files at startup.
3. Append the following options to the Prolog executable complete 
   filename, depending on the Prolog interpreter you use:
   (a) SICStus Prolog: -l des.pl
   (b) SWI Prolog: -g "ensure_loaded(des)" (remove --win_app if present)
Another alternative is to write a batch file similar to the 
script file described just in the above section.
    
================================================
Linux/MacOSX Source Distributions
================================================
You can write a script for starting DES according to the 
selected Prolog interpreter, as follows:
(a) SICStus Prolog: 
    $SICSTUS -l des.pl 
    Provided that $SICSTUS is the variable which holds 
    the absolute filename of the SICStus Prolog executable.
(b) SWI Prolog: 
    $SWI -g "ensure_loaded(des)"
    Provided that $SWI is the variable which holds the 
    absolute filename of the SWI Prolog executable.

================================================
More Information: 
================================================

- See User Manual
  'Documentation' entry in 
  http://www.fdi.ucm.es/profesor/fernan/des/html/download.html
- http://des.sourceforge.net


Version Devel of DES (released on July, 12th, 2015)
 
* Enhancements:
  o Datalog and SQL debugging omits questions abount nodes in subtrees of valid nodes
  
* Changes:
  o 
  
* Fixed bugs:
  o Removed non-relational predicates which innecesarily occurred in the Prolog program when debugging a local SQL database
