/*********************************************************/
/*                                                       */
/* DES: Datalog Educational System v.Devel               */
/*                                                       */
/*    HR-SQL Subsystem                                   */
/*                                                       */
/*                                                       */
/*                                                       */
/*                                          Susana Nieva */
/*                                  Fernando Saenz-Perez */
/*                               Jaime Sanchez-Hernandez */
/*                                         (c) 2004-2015 */
/*                                    DSIC DISIA GPD UCM */
/*             Please send comments, questions, etc. to: */
/*                                     fernan@sip.ucm.es */
/*                                Visit the Web site at: */
/*                           http://des.sourceforge.net/ */
/*                                                       */
/* This file is part of DES.                             */
/*                                                       */
/* DES is free software: you can redistribute it and/or  */
/* modify it under the terms of the GNU Lesser General   */
/* Public License as published by the Free Software      */
/* Foundation, either version 3 of the License, or (at   */
/* your option) any later version.                       */
/*                                                       */
/* DES is distributed in the hope that it will be useful,*/
/* but WITHOUT ANY WARRANTY; without even the implied    */
/* warranty of MERCHANTABILITY or FITNESS FOR A          */
/* PARTICULAR PURPOSE. See the GNU Lesser General Public */
/* License for more details.                             */
/*                                                       */
/* You should have received a copy of the GNU Lesser     */
/* General Public License and GNU General Public License */
/* along with this program. If not, see:                 */
/*                                                       */
/*            http://www.gnu.org/licenses/               */
/*********************************************************/

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% HR-SQL Version 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

hrsql_version('2.0').


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% HR-SQL RDBMS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

:- dynamic(hrsql_connection/1).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% HR-SQL Database File
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

:- dynamic(hrsql_file/1).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Python File
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

:- dynamic(hrsql_py_file/1).
hrsql_py_file('script.py').


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Transform Flag. Enabled when transform is operating
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

:- dynamic(hrsql_transform/1).
hrsql_transform(off).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Processing Inputs 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

process_hrsql(QueryStr) :-
  write_info_verb_log(['Parsing query...']),
%  parse_dql_query(Query,QueryStr,[]), 
  parse_sql_query(Query,QueryStr,[]), 
  write_info_verb_log(['Query successfully parsed.']),
  store_elapsed_time(parsing),
  reset_rel_id,
  solve_hrsql_query(QueryStr,Query),
  !.
%process_hrsql(_QueryStr).
  
solve_hrsql_query(_QueryStr,Query) :-
  my_member_term(with(_,_),Query),
  !,
  create_view(sql,Query,answer,_LVDs),
  process_hrsql_query(Query).
solve_hrsql_query(_QueryStr,create_or_replace_view(hrsql,_,_)) :-
  !,
  fail. % Let DES create the view in the local database
solve_hrsql_query(QueryStr,Query) :-
  hrsql_connection(Connection),
  solve_rdb_sql_query(Connection,QueryStr,Query).
  %solve_rdb_dql_query(Connection,QueryStr).

process_hrsql_query(_Query) :-
  check_non_stratifiable,
  !,
  drop_view(answer).
process_hrsql_query(Query) :-
  Answer=answer,
  str(Query,St),
  view_arity(Answer,Arity),
  get_table_typed_schema(Answer,Schema),
  tr_while(St,[(Answer/Arity,St)],_StrataO,[create_view(sql,Query,Schema)],DB),
  remove_from_list(create_view(sql,_,Schema),DB,DBO),
  reldef_node_list(DBO,RNp),
  hrsql_py_file(PythonFileName),
  typed_schema_to_untyped_schema(Schema,USchema),
  view_sql(Answer,Arity,SQLst),
%  display_to_string(display_sql(SQLst,0),SQLstStr),
  code_generate(DBO,_ExtendedStrata,query(SQLst,USchema),PythonFileName,RNp,RNp,[]),
  execute_py_script(PythonFileName,Status),
  ((Status==0
    ;
    Status==(-1073741819))
   ->
    hrsql_connection(Connection),
    opened_db(Connection,_,DBMS),
    schema_to_colnames(Schema,Colnames),
    delimited_dbms_sql_identifier_list(Colnames,DBMS,DColnames),
%    with_output_to_codes(display_sequence(ColNames),ColsStr),
    display_to_string(display_sequence(DColnames),ColsStr),
%    escape_double_quotes_str(ColsStr,EColsStr),
    append("SELECT * FROM answer ORDER BY ",ColsStr,QueryAnswerStr),
    solve_rdb_dql_query(Connection,QueryAnswerStr)
%    display_relation_contents(RN_RNp)
   ;
    true),
  drop_view(answer).
process_hrsql_query(_Query) :-
  my_raise_exception('','Failed processing of HR-SQL query.',[]).
  
create_external_table_from_reldef_list([]).
create_external_table_from_reldef_list([RelDef|RelDefs]) :-
  create_external_table_from_reldef(RelDef),
  create_external_table_from_reldef_list(RelDefs).
  
create_external_table_from_reldef(RelDef) :-
  display_to_string(display_sql(RelDef,0),SQLStr),
  solve_rdb_ddl_query(SQLStr).
  
reldef_node_list([],[]).
reldef_node_list([create_view(sql,_Query,Schema)|RelDefs],[Name/Arity|Nodes]) :-
  functor(Schema,Name,Arity),
  reldef_node_list(RelDefs,Nodes).
  
  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Processing Commands 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%
% /hrsql Connection
%
% Set hrsql mode and open Connection. Default database is left as the current one
%
process_hrsql_command(hrsql,[Connection]) :-
  (Connection=='$des'
   ->
    write_warning_log(['Default database ''$des'' cannot be used for HR-SQL. Specify an ODBC connection instead.'])
   ;
    processC(system_mode,[hrsql],[],_),
    display_hrsql_banner,
    write_info_verb_log(['Switched to HR-SQL system.']),
    processC(open_db,[Connection],[],_),
    set_flag(hrsql_connection,Connection),
    processC(use_ddb,[],[],_)
  ).
  
%
% /load_db File
%
% Load the database in file HRSQLFileName
%
process_load_db_command(load_db,Args) :-
  process_load_db_command(load_db,Args,_).
  
process_load_db_command(load_db,[_HRSQLFileName],true) :-
  check_default_database.
process_load_db_command(load_db,[HRSQLFileName],Error) :-
  processC(abolish,[],[],_),
  processC(batch,[on],_,yes),
  process_batch(HRSQLFileName,Error),
  processC(batch,[off],_,yes),
  (Error==true
   ->
    true
   ;
    set_flag(hrsql_file,HRSQLFileName),
    compute_stratification,     % Stratification for the HR-SQL database
    write_log_list(['Application of preprocessing gives:',nl]),
    list_relations).
%
% /transform_db
%
% Transform the HR-SQL database loaded already into an R-SQL database
%
process_transform_db_command(transform_db,[]) :-
  reset_rel_id,
  rel_strata(Strata),
  transform(Strata,_ExtendedStrata,SQLsts,_RN,_RNp,_RN_RNp),
  write_log_list(['Application of transform gives:',nl]),
  list_hrsq_reldefs(SQLsts,0).
  
%
% /process_db File
%
% Load and process the database in file HRSQLFileName
process_process_db_command(process_db,[HRSQLFileName]) :-
  process_load_db_command(load_db,[HRSQLFileName],Error),
  (Error==true
   ->
    true
   ;
    hrsql_py_file(PythonFileName),
    process_process_db_command(process_db,HRSQLFileName,PythonFileName)).

%
% /process_db
%
% Process the database loaded already
%
process_process_db_command(process_db,[]) :-
  hrsql_file(HRSQLFileName),
  hrsql_py_file(PythonFileName),
  process_process_db_command(process_db,HRSQLFileName,PythonFileName).

process_process_db_command(process_db,_HRSQLFileName,_PythonFileName) :-
  check_non_stratifiable,
  !.
process_process_db_command(process_db,_HRSQLFileName,_PythonFileName) :-
  check_default_database.
process_process_db_command(process_db,HRSQLFileName,PythonFileName) :-
  reset_rel_id,
  rel_strata(Strata),
  transform(Strata,ExtendedStrata,SQLsts,RN,RNp,RN_RNp),
  write_log_list([nl,'R-SQL Database: ',nl]),
  list_hrsq_reldefs(SQLsts,2),
%  display_sql_list(SQLsts,2,hrsql),
  !, % WARNING: Should not be needed!
  display_strata(Strata,ExtendedStrata),
  code_generate(SQLsts,ExtendedStrata,file(HRSQLFileName),PythonFileName,RN,RNp,RN_RNp),
  execute_py_script(PythonFileName,Status),
  ((Status==0
    ;
    Status==(-1073741819))
   ->
    my_sort(RN_RNp,ORN_RNp),
    display_relation_contents(ORN_RNp)
   ;
    true).
%  true.

check_non_stratifiable :-
  strata([non-stratifiable]),
  write_error_log(['Non stratifiable database']).
  
display_strata(Strata,NewStrata) :-
  nl_log,
  write_log_list(['Original Strata   : ',Strata,nl]),
  write_log_list(['Extended Strata   : ',NewStrata,nl]).

check_default_database :-
  current_db(Connection),
  Connection\=='$des',
  !,
  write_error_log(['Use default database to process this command with: /use_ddb']).

  
%
% /list_relations 
%
% List relation definitions loaded in the local database.
% This command calls list_hrsql_relations in system mode hrsql.
list_hrsql_relations :-
  get_viewnames(_,ViewNames),
  view_arity_list(ViewNames,Nodes),
  view_sql_list(ViewNames,SQLsts),
  my_zipWith(',',Nodes,SQLsts,RNSQLsts),
  create_view_from_RNsqlst_list(RNSQLsts,RelDefs),
  list_hrsq_reldefs(RelDefs,0).
  
list_hrsq_reldefs(RelDefs,Indent) :-
  push_flag(pretty_print,off,OldFlag),
  my_mergesort(RelDefs,reldef_compare,ORelDefs),
  display_sql_list(ORelDefs,Indent,hrsql),
  pop_flag(pretty_print,OldFlag).
  
% % Schema comparison predicate for mergesort: Sorts ascending on the name of the relation
% schema_compare((_,[LR|_]),(_,[RR|_])) :-
%   LR @=< RR.
% Relation definition comparison predicate for mergesort: Sorts ascending on the name of the relation
reldef_compare(create_view(_,_,LR),create_view(_,_,RR)) :-
  LR @=< RR.

create_view_from_RNsqlst_list([],[]).
create_view_from_RNsqlst_list([(RelName/_Arity,SQLst)|SQLsts],[create_view(sql,SQLst,Schema)|RelDefs]) :-
  get_table_typed_schema(RelName,Schema),
  create_view_from_RNsqlst_list(SQLsts,RelDefs).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Preprocessing Queries
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description:
%   Given an HR-SQL query, replace
%   nested ASSUME queries by new relations.
%   It also returns the list of new relation definitions (SQLst,Schema)
% Follows grammar in Figures 1 and 3.

% hrsql_preprocess(+SQLst,-RSQLst,-LVDs)
%hrsql_preprocess((with(SQLst,SQLsts),Schema),with(RSQLst,RSQLsts),LVDs) :-
hrsql_preprocess(SQLst,SQLst,[]) :-
  (hrsql_transform(on) % Do not preprocess if transform is operating
   ;
   system_mode(Mode),
   Mode\==hrsql
  ),
  !.
hrsql_preprocess((with(SQLst,[HSQLst1,HSQLst2|HSQLsts]),Schema),WSQLst,LVDs) :-
  replace_sel_hyp_by_rel(HSQLst1,RHSQLst1,LVDs1),
  hrsql_preprocess((with(SQLst,[HSQLst2|HSQLsts]),Schema),RSQLst,LVDs2),
  hrsql_preprocess((with(RSQLst,[RHSQLst1]),Schema),WSQLst,LVDs3),
  concat_lists([LVDs1,LVDs2,LVDs3],LVDs).
% hrsql_preprocess((with(SQLst,[HSQLst1,HSQLst2|HSQLsts]),Schema),WSQLst,LVDs) :-
%   replace_sel_hyp_by_rel(HSQLst1,RHSQLst1,LVDs1),
%   hrsql_preprocess((with(SQLst,[HSQLst2|HSQLsts]),Schema),RSQLst,LVDs2),
%   WSQLst=(with(RSQLst,[RHSQLst1]),Schema),
%   LVDs3=[],
%   concat_lists([LVDs1,LVDs2,LVDs3],LVDs).
hrsql_preprocess((with(SQLst,[HSQLst]),Schema),(with(RSQLst,[RHSQLst]),Schema),LVDs) :-
  !,
%  replace_sel_hyp_by_rel(SQLst,RSQLst,LVDs1),
  hrsql_preprocess(SQLst,RSQLst,LVDs1),
  replace_sel_hyp_by_rel(HSQLst,RHSQLst,LVDs2),
  append(LVDs1,LVDs2,LVDs).
hrsql_preprocess((union(D,SQLst1,SQLst2),Schema),(union(D,RSQLst1,RSQLst2),Schema),LVDs) :-
  !,
  hrsql_preprocess(SQLst1,RSQLst1,LVDs1),
  hrsql_preprocess(SQLst2,RSQLst2,LVDs2),
  append(LVDs1,LVDs2,LVDs).
hrsql_preprocess((except(D,SQLst1,SQLst2),Schema),(except(D,RSQLst1,RSQLst2),Schema),LVDs) :-
  !,
  hrsql_preprocess(SQLst1,RSQLst1,LVDs1),
  hrsql_preprocess(SQLst2,RSQLst2,LVDs2),
  append(LVDs1,LVDs2,LVDs).
hrsql_preprocess(SQLst,SQLst,[]).
  
replace_sel_hyp_by_rel(SQLst,RSQLst,LVDs) :-
  replace_sel_hyp_by_rel(SQLst,RSQLst,[],LVDs).

replace_sel_hyp_by_rel(T,T,Is,Is) :- 
  (number(T) ; var(T) ; atom(T)),
  !.
replace_sel_hyp_by_rel(
    (with(SQLst,SQLsts),Schema),
    (select(all,top(all),*,from([(NewRel,_AS)]),where(true),group_by([]),having(true),order_by([],[])), Schema),
    LVDsI,
    [(with(RSQLst,RSQLsts),NSchema)|LVDsO]) :-
  !,
  new_relation_name('R',NewRel),
  NSchema=NewRel, % For schema-less view definitions
%  build_prototype_view_list([(_,NSchema)],_),
%  rename_relation_schema(Schema,NewRel,NSchema),
  replace_sel_hyp_by_rel(SQLst,RSQLst,LVDsI,LVDsI1),
  replace_sel_hyp_by_rel(SQLsts,RSQLsts,LVDsI1,LVDsO).
replace_sel_hyp_by_rel(C,RC,Is,Os) :- 
  C =.. [F|As],
  !, 
  replace_sel_hyp_by_rel_list(As,RAs,Is,Os),
  RC =.. [F|RAs].

replace_sel_hyp_by_rel_list([],[],Is,Is) :-
  !.
replace_sel_hyp_by_rel_list([T|Ts],[RT|RTs],Is,Os) :-
  !, 
  replace_sel_hyp_by_rel(T,RT,Is,Is1), 
  replace_sel_hyp_by_rel_list(Ts,RTs,Is1,Os).


  

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Transform algorithm
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description:
%   Transform an HR-SQL database into an R-SQL database
% Input:
%   - Views (schema and definitions)
%   - Strata
% Output:
%   - Replaced view definitions (i.e., those containing some assume clause)
%   - New view definitions along their strata
% View definitions are stored in local metadata (my_view)
% Strata and DG are supposed to be already computed and stored in the dynamic database
%

% transform(+Strata,-NewOrderedStrata,-DBO,-RN,-RNp,-RN_RNp)
% original DB in my_view
% DBO is a list of create_view(sql,SQLst,Schema)
transform(Strata,NewOrderedStrata,DBO,RN,RNp,RN_RNp) :-
  max_stratum(Strata,NumStr),
  get_hrsql_db_from_strata(Strata,DBI),
  set_flag(hrsql_transform,on),
  transform_while(1,NumStr,Strata,NewStrata,DBI,DBO),
  set_flag(hrsql_transform,off),
  my_mergesort(NewStrata,stratum_compare,NewOrderedStrata),
  hrsql_relnames_from_strata(Strata,NewOrderedStrata,RN,RNp,RN_RNp).

transform_while(I,NumStr,Strata,Strata,DB,DB) :-
  I>NumStr,
  !.
transform_while(I,NumStr,StrataI,StrataO,DBI,DBO) :-
  tr_while(I,StrataI,StrataI1,DBI,DBI1),
  I1 is I+1,
  transform_while(I1,NumStr,StrataI1,StrataO,DBI1,DBO).

% tr_while(I,Strata,Strata,DB,DB) :-
%   num_assum(I,Strata,DB,0),
%   !.
tr_while(I,StrataI,StrataO,DBI,DBO) :-
  tr(I,StrataI,StrataI1,DBI,DBI,DBI1,NotFound),
  (NotFound==true
   ->
    DBO=DBI1,
    StrataO=StrataI1
   ;
    tr_while(I,StrataI1,StrataO,DBI1,DBO)).

% Transform the first relation found at stratum I
tr(I,[(Node,St)|Strata],[(Node,St)|Strata],_,DB,DB,true) :-
  St>I,
  !.
tr(I,[(Node,St)|StrataI],[(Node,St)|StrataO],DB,DBI,DBO,NotFound) :-
  St<I,
  !,
  tr(I,StrataI,StrataO,DB,DBI,DBO,NotFound).
tr(_I,[],[],_,DB,DB,true) :-
  !.
tr(I,[(Node,I)|StrataI],[(Node,I)|StrataO],DB,DBI,DBO,_Found) :-
  transform_rel(Node,I,DB,DBI,DBO,TempNodesStrata), % Failure means that Node contains no assume
%   my_set_diff(DBO,DBI,SQLsts),
%   write_log_list([nl,'BEGIN Transformed HR-SQL Relation ',Node,': ',nl]),
%   display_sql_list(SQLsts,2),
%   write_log_list(['END   Transformed HR-SQL Relation ',Node,nl]),
  !,
  append(TempNodesStrata,StrataI,StrataO).
tr(I,[(Node,I)|StrataI],[(Node,I)|StrataO],DB,DBI,DBO,NotFound) :-
  tr(I,StrataI,StrataO,DB,DBI,DBO,NotFound).

% Failure means that RelName/Arity contains no assume:
transform_rel((RelName/Arity),Stratum,DB,[create_view(sql,SQLst,Schema)|DBI],[RRelDef|DBO],TempNodesStrata) :-
  functor(Schema,RelName,Arity),
  !,
%  (RelName/Arity==v/1 -> deb ; true),
  replace_sel_hyp(SQLst,RelName,Stratum,DB,RSQLst,TempNodesStrata,DBI1),
  RRelDef=create_view(sql,RSQLst,Schema),
  create_prototype_reldef_list(DBI1),
  solve_create_or_replace_view_list(DBI1),      % Ri
  solve_create_or_replace_view_list([RRelDef]), % Rh
  append(DBI,DBI1,DBO),
  write_log_list([nl,'Application of tr gives: ',nl]),
  list_relations.
transform_rel((RelName/Arity),Stratum,DB,[RelDef|DBI],[RelDef|DBO],TempNodesStrata) :-
  transform_rel((RelName/Arity),Stratum,DB,DBI,DBO,TempNodesStrata).
  
% replace_sel_hyp(+SQLst,+RelName,+Stratum,+DB,-RQLst,-NewNodesStrata,-NewSQLsts).
replace_sel_hyp((SQLst,_),RelName,Stratum,DB,RSQLst,NewNodesStrata,NewSQLsts) :-
  replace_sel_hyp(SQLst,RelName,Stratum,DB,RSQLst,NewNodesStrata,NewSQLsts).
% replace_sel_hyp(with(SQLst,SQLsts),RelName,Stratum,DB,with(RSQLst,SQLsts),NewNodesStrata,NewSQLsts) :-
%   replace_sel_hyp(SQLst,RelName,Stratum,DB,RSQLst,NewNodesStrata,NewSQLsts),
%   !.
replace_sel_hyp(union(D,SQLst1,SQLst2),RelName,Stratum,DB,union(D,RSQLst1,SQLst2),NewNodesStrata,NewSQLsts) :-
  replace_sel_hyp(SQLst1,RelName,Stratum,DB,RSQLst1,NewNodesStrata,NewSQLsts).
replace_sel_hyp(union(D,SQLst1,SQLst2),RelName,Stratum,DB,union(D,SQLst1,RSQLst2),NewNodesStrata,NewSQLsts) :-
  replace_sel_hyp(SQLst2,RelName,Stratum,DB,RSQLst2,NewNodesStrata,NewSQLsts).
replace_sel_hyp(with(SQLst,SQLsts),RelName,Stratum,DB,RSQLst,NewNodesStrata,NewSQLsts) :-
  !,
  % List of hypo:
  queries_by_new_relation(SQLsts,RelSQLstsList,ARenamings),
  my_unzip(ARenamings,_,ANewNodes),
  depend_on_renamings(SQLst,ANewNodes,DepRenamings),
  remove_from_list(((_/Arity)/(RelName/Arity)),DepRenamings,DRenamings),
  my_set_union(ARenamings,DRenamings,Renamings),
  % R'a sch_a := query_a sigma union|except query' sigma:
  hrsql_connection(Connection),
  opened_db(Connection,_Handle,DBMS),
  new_assume_relation_definition_list(RelSQLstsList,Renamings,DBMS,TNewSQLsts),
  new_depend_on_relation_definition_list(DRenamings,Renamings,DB,DNewSQLsts),
  transformed_nodes_stratum(Renamings,Stratum,NewNodesStrata),
  append(TNewSQLsts,DNewSQLsts,NewSQLsts),
  % Ra sch_a := query_a:
  apply_renaming_list(Renamings,SQLst,RSQLst).
%replace_sel_hyp(SQLst,_Strata,_RelName,SQLst,[],[]).
  
depend_on_renamings(SQLst,ANewNodes,DRenamings) :-
  % R_1 sch_1 := query_1
  % R'_1 sch_1 := query_1 sigma
  % ... :
  rn_query(SQLst,RNs),
  depend_nodes_on_list(RNs,ANewNodes,RiList),
  findall(
    ((Ren/Arity)/(Rel/Arity)),
    (member(Rel/Arity,RiList),
     new_relation_name(Rel,Ren)
     ),
    DRenamings).
    
% Set of RN relations in query
rn_query((SQLst,_),RNs) :-
  get_view_relations_from_sql(SQLst,Rels),
  remove_from_list(dual,Rels,RRels),
  view_arity_list(RRels,RNs).
 
% Retrieving the DB in strata from the dynamic database
get_hrsql_db_from_strata([],[]).
get_hrsql_db_from_strata([(RelName/Arity,_St)|Strata],[create_view(sql,SQLst,Schema)|DB]) :-
  view_sql(RelName,Arity,SQLst),
  get_table_typed_schema(RelName,Schema),
  get_hrsql_db_from_strata(Strata,DB).  
  
% Determine those Ri \in RN s.t. Ri depends on any Node in Nodes
depend_nodes_on_list(RNs,Nodes,DepNodes) :-
  pdg((_,As)),
  depend_nodes_on_list(RNs,Nodes,As,[],AllDepNodes),
  my_remove_duplicates_sort(AllDepNodes,SortedDepNodes),
  filter_relation_nodes(SortedDepNodes,RelDepNodes),
  my_set_diff(RelDepNodes,Nodes,DepNodes).
  
depend_nodes_on_list([],_Nodes,_As,DepNodes,DepNodes).
depend_nodes_on_list([R|RNs],Nodes,As,DepNodesI,DepNodesO) :-
  pdg_path_list(R,Nodes,As,DepNodesT),
  !,
  append(DepNodesI,DepNodesT,DepNodesI1),
  depend_nodes_on_list(RNs,Nodes,As,DepNodesI1,DepNodesO).
% depend_nodes_on_list([_R|RNs],Nodes,RiList) :-
%   depend_nodes_on_list(RNs,Nodes,RiList).

pdg_path_list(R,[Node|_Nodes],As,NsO) :-
  findall(Ns,pdg_path(Node,R,As,[],_,[],Ns),NsList),
  concat_lists(NsList,NsO).
  
filter_relation_nodes([],[]).
filter_relation_nodes([R/A|Ns],[R/A|RNs]) :-
  relation_exists(R),
  !,
  filter_relation_nodes(Ns,RNs).
filter_relation_nodes([_N|Ns],RNs) :-
  filter_relation_nodes(Ns,RNs).
  
% replace_sel_hyp_list([],[],_RelName,_Stratum,_DB,NewNodesStrata,NewNodesStrata,NewSQLsts,NewSQLsts).
% replace_sel_hyp_list([(SQLst,_)|SQLsts],[RSQLst|RSQLsts],RelName,Stratum,DB,NewNodesStrataI,NewNodesStrataO,NewSQLstsI,NewSQLstsO) :-
%   replace_sel_hyp(SQLst,RelName,Stratum,DB,RSQLst,NewNodesStrataT,NewSQLstsT),
%   !,
%   append(NewNodesStrataI,NewNodesStrataT,NewNodesStrataI1),
%   append(NewSQLstsI,NewSQLstsT,NewSQLstsI1),
%   replace_sel_hyp_list(SQLsts,RSQLsts,RelName,Stratum,DB,NewNodesStrataI1,NewNodesStrataO,NewSQLstsI1,NewSQLstsO).
% replace_sel_hyp_list([SQLst|SQLsts],[SQLst|RSQLsts],RelName,Stratum,DB,NewNodesStrataI,NewNodesStrataO,NewSQLstsI,NewSQLstsO) :-
%   replace_sel_hyp_list(SQLsts,RSQLsts,RelName,Stratum,DB,NewNodesStrataI,NewNodesStrataO,NewSQLstsI,NewSQLstsO).

apply_renaming_list([],SQLst,SQLst).
apply_renaming_list([Renaming|Renamings],SQLst,RSQLst) :-
  apply_renaming(Renaming,SQLst,TSQLst),
  apply_renaming_list(Renamings,TSQLst,RSQLst).
  
apply_renaming(((Ren/Arity)/(Rel/Arity)),SQLst,RSQLst) :-
%  replace_term(Rel,Ren,SQLst,RSQLst).
  replace_functor(Rel,Ren,SQLst,RSQLst).

% new_depend_on_relation_definition_list(+DependOnRenamings,+Renamings,+DB,-NewSQLsts)
new_depend_on_relation_definition_list([],_DB,_Renamings,[]).
new_depend_on_relation_definition_list([((RenName/Arity)/(RelName/Arity))|RenRelList],Renamings,DB,[create_view(sql,RenDef,RenSchema)|RelDefSQLstsList]) :-
  get_table_typed_schema(RelName,Schema),
  rename_relation_schema(Schema,RenName,RenSchema),
  view_sql(RelName,SQLst), 
%  view_sql_schema_from_db(RelName,_,DB,Renamings,SQLst,RelSchema),
%  rename_relation_schema(RelSchema,RenName,RenSchema),
  apply_renaming_list(Renamings,SQLst,RenDef),
  new_depend_on_relation_definition_list(RenRelList,Renamings,DB,RelDefSQLstsList).
  
rename_relation_schema(Schema,RenName,RenSchema) :-
  Schema=..[_RelName|TCols],
  RenSchema=..[RenName|TCols].

% view_sql_schema_from_db(RelName,RenName,DB,Renamings,SQLst,RelSchema) :-
%   member(((RenName/Arity)/(RelName/Arity)),Renamings),
%   functor(RelSchema,RelName,Arity),
%   member(create_view(sql,SQLst,RelSchema),DB).

% new_assume_relation_definition_list(+RelSQLstsList,+Renamings,+DBMS,-NewSQLsts)
new_assume_relation_definition_list([],_Renamings,_DBMS,[]). 
new_assume_relation_definition_list([(RelName,SQLsts)|RelSQLstsList],Renamings,DBMS,[create_view(sql,RelDef,RenSchema)|RelDefSQLstsList]) :-
%  view_sql_schema_from_db(RelName,RenName,DB,Renamings,SQLst,RelSchema),
%  rename_relation_schema(RelSchema,RenName,RenSchema),
  view_sql(RelName,SQLst),
  get_table_typed_schema(RelName,Schema),
  member(((RenName/Arity)/(RelName/Arity)),Renamings),
  rename_relation_schema(Schema,RenName,RenSchema),
  apply_renaming_list(Renamings,SQLsts,RSQLsts),
  apply_renaming_list(Renamings,SQLst,RSQLst),
  new_relation_definition(RSQLsts,RSQLst,RelDef),
  new_assume_relation_definition_list(RelSQLstsList,Renamings,DBMS,RelDefSQLstsList). 

% SQLsts, Left arg, Expr.
new_relation_definition([],SQLst,SQLst).
new_relation_definition([SQLst],SQLst,SQLst).
new_relation_definition([not(SQLstR)|SQLsts],SQLstL,SQLst) :-
  !,
  new_relation_definition(SQLsts,except(all,SQLstL,SQLstR),SQLst).
new_relation_definition([SQLstR|SQLsts],SQLstL,SQLst) :-
  !,
  new_relation_definition(SQLsts,union(distinct,SQLstL,SQLstR),SQLst).


% Group by relation name in the assume list and map each relation to all its related SQLsts (SQLst, not(SQLst))
% Return also the renamings RenRN/RelRN
queries_by_new_relation(SQLsts,RelSQLstsList,Renamings) :- 
  setof(Rel,
    SQLst^Schema^TCols^
    (member((SQLst,Schema),SQLsts),
     Schema=..[Rel|TCols],
     length(TCols,Arity)),
    Rels),
  setof(
    ((Rel,RelSQLsts),((Ren/Arity)/(Rel/Arity))),
    SQLst^Schema^TCols^
    (
     member(Rel,Rels),
     new_relation_name(Rel,Ren),
     findall(
       SQLst,
       (member((SQLst,Schema),SQLsts),
        Schema=..[Rel|_]),
       RelSQLsts)
    ),
    RelSQLstsRenList
    ),
    my_unzip(RelSQLstsRenList,RelSQLstsList,Renamings).
    
transformed_nodes_stratum([],_Stratum,[]).
transformed_nodes_stratum([((Ren/Arity)/(_Rel/Arity))|Renamings],Stratum,[(Ren/Arity,Stratum)|TNodesStrata]) :-
  transformed_nodes_stratum(Renamings,Stratum,TNodesStrata).
  
new_relation_name(Rel,NRel) :-
  atom_codes(Rel,RelStr),
  get_rel_id(I),
  new_relation_name_aux(RelStr,I,NRelStr),
  atom_codes(NRel,NRelStr).

new_relation_name_aux(RelStr,I,NRelStr) :-
  [US]="_",
  number_codes(I,Is),
  concat_lists([RelStr,[US],Is],Str),
  atom_codes(NRel,Str),
  (relation_exists(NRel)
   ->
    get_rel_id(I1),
    new_relation_name_aux(RelStr,I1,NRelStr)
   ;
    NRelStr=Str).
    
    
% Relation identifiers 
:- dynamic(rel_id/2). 

get_rel_id(Id) :-
  get_rel_id(_O,Id).
  
get_rel_id(O,OId) :-
  (rel_id(O,IId) -> 
   OId is IId+1,
   retract(rel_id(O,IId))
   ; 
   OId is 0),
  assertz(rel_id(O,OId)).

reset_rel_id :-
  retractall(rel_id(_O,_I)).

% Alias identifiers 
:- dynamic(alias_id/2). 

get_alias_id(Id) :-
  get_alias_id(_O,Id).
  
get_alias_id(O,OId) :-
  (alias_id(O,IId) -> 
   OId is IId+1,
   retract(alias_id(O,IId))
   ; 
   OId is 0),
  assertz(alias_id(O,OId)).

reset_alias_id :-
  retractall(alias_id(_O,_I)).

hrsql_relnames_from_strata(Strata,NewOrderedStrata,RN,RNp,RN_RNp) :-
  my_unzip(Strata,RN_RNp,_),
  my_unzip(NewOrderedStrata,RN,_),
  my_set_diff(RN,RN_RNp,RNp).
  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Code Generation algorithm
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description:
%   Generate Python code for solving HR-SQL databases
% Input:
%   - Original Strata
%   - Extended Strata (with the new relations introduced by the transform algorithm)
% Output:
%   - File
%

code_generate(SQLsts,_ExtendedStrata,HRSQLFileQuery,PythonFileName,RNI,RNpI,RN_RNp) :-
  filter_drop_auxiliary_unused_relations(RNI,RNpI,RN_RNp,HRSQLFileQuery,RN,RNp),
%  filter_drop_unused_relations(RN_RNpI,RN_RNp), % Original relations
%  compute_stratification_for(ExtendedStrata,SQLsts),
  rel_strata(Strata),
  write_log_list(['Final Strata      : ',Strata,nl,nl]),
  write_log_list(['Python Script for R-SQL Database:',nl,nl]),
  hrsql_version(Version),
  hrsql_connection(Connection),
  my_odbc_get_dbms(Connection,LDBMS),
  ldbms_dbms(LDBMS,DBMS),
  processC(log,[write,normal,PythonFileName],[],_),
  push_flag(pretty_print,off,OldValue),
  display_py_banner(Version,HRSQLFileQuery,PythonFileName,Connection,DBMS),
  display_py_prelude(Connection),
  display_py_create_answer(HRSQLFileQuery,LDBMS),
  display_py_drop_create_tables(RN_RNp,LDBMS),
  display_py_create_temporary_tables(RNp,LDBMS),
  display_py_strata_computation(RN,SQLsts,LDBMS),
  display_py_answer(HRSQLFileQuery,LDBMS),
  display_py_drop_temporary_tables(RNp,LDBMS),
  display_py_commit,
  display_py_success,
  pop_flag(pretty_print,OldValue),
  processC(nolog,[PythonFileName],[],_).

% compute_stratification_for(Strata,SQLsts) :-
%   processC(batch,[on],_,yes),
%   solve_create_or_replace_view_list_on_strata(Strata,SQLsts),
%   processC(batch,[off],_,yes),
%   compute_stratification.     % Max. Stratification for the R-SQL database

reachable_relations_list(Nodes,ReachableNodes) :-
  reachable_node_list(Nodes,RNodes),
  my_remove_duplicates_sort(RNodes,SNodes),
  filter_relation_nodes(SNodes,ReachableNodes).
  
filter_drop_auxiliary_unused_relations(RN,RNp,_RN_RNp,query(_,_),RN,RNp) :-
  !.
filter_drop_auxiliary_unused_relations(RNI,RNpI,RN_RNp,_HRSQLFileQuery,RN,RNp) :-
  rel_strata(Strata),
  write_log_list(['Unfiltered Strata : ',Strata,nl]),
  reachable_relations_list(RN_RNp,RNs),
  filter_drop_unused_relations(RNI,RNs,RN),
  filter_drop_unused_relations(RNpI,RNs,RNp).
  
filter_drop_unused_relations(Nodes,RNodes,FNodes) :-
  my_set_diff(Nodes,RNodes,DNodes),
  my_unzip(DNodes,TableNames,_Arities),
  drop_viewname_u_if_exists_list(TableNames),
  my_set_diff(Nodes,DNodes,FNodes).


% solve_create_or_replace_view_list_on_strata([],_SQLsts).
% solve_create_or_replace_view_list_on_strata([(RelName/Arity,_St)|Strata],SQLsts) :-
%   functor(Schema,RelName,Arity),
%   member(create_view(sql,SQLst,Schema),SQLsts),
%   solve_des_sql_query(_Lang,create_or_replace_view(sql,SQLst,Schema)),
%   solve_create_or_replace_view_list_on_strata(Strata,SQLsts).

solve_create_or_replace_view_list([]).
solve_create_or_replace_view_list([create_view(sql,SQLst,Schema)|SQLsts]) :-
  solve_des_sql_query(sql,create_or_replace_view(sql,SQLst,Schema)),
  solve_create_or_replace_view_list(SQLsts).

create_prototype_reldef_list([]).
create_prototype_reldef_list([create_view(sql,SQLst,Schema)|SQLsts]) :-
  build_prototype_view_list([(SQLst,Schema)],_),
  create_prototype_reldef_list(SQLsts).

%
% display_py_banner(+Version,+HRSQLFileName,+PythonFileName,+Connection,+DBMS)
%
display_py_banner(Version,HRSQLFileQuery,PythonFileName,Connection,DBMS) :-
  file_query_display(HRSQLFileQuery,FileQueryDisplay),
  prolog_system(Prolog,_Version),
  my_datetime((YYYY,MM,DD,H,M,S)),
  write_log_list(['###############################################################',nl]),
  write_log_list(['# HR-SQL ',Version,nl]),
  write_log_list(['# Python script for:',nl]),
  write_log_list(FileQueryDisplay),
  write_log_list(['#   - This Python Filename: ',PythonFileName,nl]),
  write_log_list(['#   - ODBC Connection     : ',Connection,nl]),
  write_log_list(['#   - RDBMS               : ',DBMS,nl]),
  write_log_list(['#   - Prolog System       : ',Prolog,nl]),
  write_log_list(['#   - Date                : ',YYYY-MM-DD,nl]),
  write_log_list(['#   - Time                : ',H:M:S,nl]),
  write_log_list(['#',nl]),
  write_log_list(['# Run this script with the ODBC connection defined already at ',nl]),
  write_log_list(['#   the OS level and the database system up and running.',nl]),
  write_log_list(['###############################################################',nl,nl]).
  
file_query_display(file(HRSQLFileName),
                 ['#   - Database Filename   : ',HRSQLFileName,nl]).
file_query_display(query(_,_),
                 ['#   - This is a database query at the system prompt.',nl]).

%
% display_py_prelude(+Connection)
% 
display_py_prelude(Connection) :-
  display_py_remark(['Importing modules:',nl]),
  write_log_list(['import pyodbc',nl,
                  'import sys',nl,
                  nl]),
  display_py_remark(['Try to open the ODBC connection:',nl]),
  display_py_try_except(
    ['conn = pyodbc.connect("DSN=',Connection,'")',nl],
    ['print("Error opening connection ''',Connection,'''.")',nl,
     'sys.exit()',nl,nl]),
  display_py_remark(['Cursor definition:',nl]),
  write_log_list(['cursor=conn.cursor()',nl,nl]).

  
%
% display_py_drop_create_tables(+Nodes,+DBMS)
% 
display_py_drop_create_tables(Nodes,DBMS) :-
  display_py_remark(['Creating RN\\RN'' Tables:',nl]),
  display_py_drop_create_table_list(Nodes,DBMS).

display_py_drop_create_table_list([],_DBMS).
display_py_drop_create_table_list([(RelName/_Arity)|Nodes],DBMS) :-
  display_py_try_pass(
    ['cursor.execute("','$exec'(display_drop_table(RelName,DBMS)),'")',nl]),
  write_log_list(['cursor.execute("', '$exec'(display_create_table(RelName,normal,DBMS)), '")',nl,nl]),
  display_py_drop_create_table_list(Nodes,DBMS).
  
%
% display_py_create_temporary_tables(+Nodes,+DBMS)
% 
display_py_create_temporary_tables(Nodes,DBMS) :-
  display_py_remark(['Creating RN'' Temporary Tables:',nl]),
  display_py_create_temporary_table_list(Nodes,DBMS),
  nl_log.

display_py_create_temporary_table_list([],_DBMS).
display_py_create_temporary_table_list([(RelName/_Arity)|Nodes],DBMS) :-
  write_log_list(['cursor.execute("', '$exec'(display_create_table(RelName,temp,DBMS)), '")',nl]),
  display_py_create_temporary_table_list(Nodes,DBMS).

%
% display_py_strata_computation(+RN,+SQLsts,+DBMS)
%
display_py_strata_computation(RN,SQLsts,DBMS) :-
  rel_strata(Strata),
  max_stratum(Strata,NumStr),
  display_py_strata_computation_by_stratum(1,NumStr,RN,SQLsts,Strata,DBMS).
  
%
% max_stratum(+Strata,-MaxStr)
%
max_stratum(Strata,MaxStr) :-
  max_stratum(Strata,0,MaxStr).
  
max_stratum([],M,M).
max_stratum([(_,I)|Sts],N,M) :-
  I<N,
  !,
  max_stratum(Sts,N,M).
max_stratum([(_,I)|Sts],_N,M) :-
  !,
  max_stratum(Sts,I,M).
  
display_py_strata_computation_by_stratum(I,NumStr,_RN,_SQLsts,_Strata,_DBMS) :-
  I>NumStr,
  !.
display_py_strata_computation_by_stratum(I,NumStr,RN,SQLsts,Strata,DBMS) :-
  display_py_remark(['Stratum ',I,':',nl]),
  relname_sql_for_strata_list(I,RN,SQLsts,Strata,RNiSQLsts),
  !,
  in_out_sql_list(RNiSQLsts,I,Strata,InRNSQLsts,OutRNSQLsts),
  display_rnsql_inserts(OutRNSQLsts,DBMS),
  display_py_create_temp_views(InRNSQLsts,DBMS,TRN), % For DBMS's featuring no EXCEPT
  display_while_in_inserts(InRNSQLsts,DBMS,TRN),
  display_py_drop_temp_views(TRN,DBMS),
  nl_log,
  I1 is I+1,
  display_py_strata_computation_by_stratum(I1,NumStr,RN,SQLsts,Strata,DBMS).
display_py_strata_computation_by_stratum(I,NumStr,RN,SQLsts,Strata,DBMS) :-
  nl_log,
  I1 is I+1,
  display_py_strata_computation_by_stratum(I1,NumStr,RN,SQLsts,Strata,DBMS).

  
display_py_create_temp_views(RNSQLsts,DBMS,TRN) :-
  dbms_without_except(DBMS),
  RNSQLsts\==[],
  !,
  nl_log,
  display_py_remark(['Views for DBMS without EXCEPT:',nl]),
  display_py_create_temp_views_list(RNSQLsts,DBMS,TRN).
display_py_create_temp_views(_RNSQLsts,_DBMS,_TRN).

display_py_create_temp_views_list([],_DBMS,[]).
display_py_create_temp_views_list([(RelName/Arity,SQLst)|RNSQLsts],DBMS,[TempRel/Arity|TRNs]) :-
  atom_concat(RelName,'_temp',TempRel),
  get_table_untyped_schema(RelName,RelSchema),
  rename_relation_schema(RelSchema,TempRel,Schema),
  display_py_create_or_replace_view(Schema,SQLst,DBMS),
  display_py_create_temp_views_list(RNSQLsts,DBMS,TRNs).

% Build the list of pairs (Node,SQLst) for the nodes RN in stratum I  
relname_sql_for_strata_list(I,RN,SQLsts,Strata,RNiSQLsts) :-
  setof((Node,SQLst),
        Name^Arity^Schema^
        (member(Node,RN),
         member((Node,I),Strata),
         Node=Name/Arity,
         functor(Schema,Name,Arity),
         member(create_view(sql,SQLst,Schema),SQLsts)),
        RNiSQLsts).
  
% display_rnsql_inserts([]) :-
%   !.
display_rnsql_inserts(RNSQLs,DBMS) :-
  display_rnsql_inserts(RNSQLs,0,DBMS).
%   ,
%   nl_log.
  
display_rnsql_inserts([],_Indent,_DBMS).
display_rnsql_inserts([(Rel/_,SQLst)|InRNSQLsts],Indent,DBMS) :-
  write_log_list(['$tab'(Indent)]),
  display_py_insert_into(Rel,SQLst,DBMS),
  display_rnsql_inserts(InRNSQLsts,Indent,DBMS).
 
display_rnsql_inserts_except([],_Indent,_DBMS,[]).
display_rnsql_inserts_except([(Rel/_,SQLst)|InRNSQLsts],Indent,DBMS,[TRN|TRNs]) :-
  write_log_list(['$tab'(Indent)]),
  reset_alias_id,
  select_from_sqlst(Rel,DBMS,ESQLst),
  insert_except_sql(Rel,SQLst,ESQLst,DBMS,DSQLst,TRN),
  display_py_insert_into(Rel,DSQLst,DBMS),
  display_py_indent(['newTuples = newTuples + cursor.rowcount',nl]),
  display_rnsql_inserts_except(InRNSQLsts,Indent,DBMS,TRNs).
 
select_from_sqlst(Rel,mysql,SQLst) :-
  !,
  get_alias_id(Id),
  atomic_concat(alias,Id,Alias),
  SQLst=select(all,top(all),*,from([(Rel,[Alias])]),where(true),group_by([]),having(true),order_by([],[])).
select_from_sqlst(Rel,_DBMS,SQLst) :-
  SQLst=select(all,top(all),*,from([(Rel,_)]),      where(true),group_by([]),having(true),order_by([],[])).

insert_except_sql(RelName,_SQLst,ESQLst,DBMS,CSQLst,(TRel/_Arity)) :-
  dbms_without_except(DBMS),
  !,
  get_table_untyped_arguments(RelName,Colnames),
%  correlate(Colnames,SQLst,ESQLst,TRel,CSQLst).
  correlate(Colnames,ESQLst,TRel,CSQLst).
insert_except_sql(_RelName,SQLst,ESQLst,_DBMS,except(all,SQLst,ESQLst),_TRN).

% correlate(Colnames,(SQLst,AS),ESQLst,TRel,(CSQLst,AS)) :-
%   !,
%   correlate(Colnames,SQLst,ESQLst,TRel,CSQLst).
% correlate(Colnames,
%     select(DISTINCT,TOP,AS,_FROM,where(WHERE),GROUPBY,HAVING,ORDERBY),
%     ESQLst,
%     TRel,
%     select(DISTINCT,TOP,AS,[(TRel,_)],where(CWHERE),GROUPBY,HAVING,ORDERBY)) :-
%   !,
%   colnames_to_internal_rep(Colnames,Sequence),
%   add_condition(WHERE,not_in(Sequence,ESQLst),CWHERE).
correlate(Colnames,
    ESQLst,
    TRel,
    select(all,top(all),*,from([(TRel,_)]),where(not_in(Sequence,ESQLst)),group_by([]),having(true),order_by([],[]))) :-
  colnames_to_internal_rep(Colnames,Sequence).

colnames_to_internal_rep([],[]).
colnames_to_internal_rep([C|Cs],[attr(_,C,_)|ICs]) :-
  colnames_to_internal_rep(Cs,ICs).
  
add_condition(true,C,C) :-
  !.
add_condition(C1,C2,and(C1,C2)).
  
% Nothing to do if no inserts
display_while_in_inserts([],_DBMS,TRN) :-
  (var(TRN) -> TRN=[] ; true).
display_while_in_inserts(RNSQLsts,DBMS,TRN) :-
  write_log_list(['ch = True',nl,
                  'while ch:',nl]),
  display_py_indent(['newTuples = 0',nl]),
  display_rnsql_inserts_except(RNSQLsts,2,DBMS,TRN),
  display_py_indent(['if (newTuples == 0): ch = False',nl]).

%
% display_py_insert_into(+Rel,+SQLst,+DBMS)
% 
display_py_insert_into(Rel,SQLst,DBMS) :-
  dbms_without_except(DBMS),
  replace_except(Rel,SQLst,RelDefs,TNs,RSQLst),
  !,
  get_table_untyped_schema(Rel,Schema),
  display_py_create_view_list(RelDefs,DBMS),
  write_log_list(['cursor.execute("','$exec'(display_insert_into(Schema,RSQLst,DBMS)),'")',nl]),
  display_py_drop_views_list(TNs,DBMS).
display_py_insert_into(Rel,SQLst,DBMS) :-
  get_table_untyped_schema(Rel,Schema),
  write_log_list(['cursor.execute("','$exec'(display_insert_into(Schema,SQLst,DBMS)),'")',nl]).


%
% display_py_create_answer(+PythonFileName,+DBMS)
% 
display_py_create_answer(query(_Query,Schema),DBMS) :-
  !,
  nl_log,
  display_py_remark(['Creating Answer Table:',nl]),
  functor(Schema,RelName,Arity),
  display_py_drop_create_table_list([(RelName/Arity)],DBMS).
display_py_create_answer(_File,_DBMS). % Nothing to do if not a query

%
% display_py_answer(+PythonFileName,+DBMS)
% 
display_py_answer(query(Query,Schema),DBMS) :-
  !,
  display_py_remark(['Inserting into Answer:',nl]),
  functor(Schema,RelName,_Arity),
  display_py_insert_into(RelName,Query,DBMS),
  nl_log.
%  display_py_create_or_replace_view(Schema,Query,DBMS).
display_py_answer(_File,_DBMS). % Nothing to do if not a query
  
display_py_create_or_replace_view(Schema,Query,DBMS) :-
  functor(Schema,ViewName,_),
  display_py_try_pass(
    ['cursor.execute("','$exec'(display_drop_view(ViewName,DBMS)),'")',nl]),
  write_log_list(['cursor.execute("', '$exec'(display_create_view(Schema,Query,DBMS)), '")',nl,nl]).

%
% display_py_drop_temporary_tables(+Nodes,+DBMS)
% 
display_py_drop_temporary_tables(Nodes,DBMS) :-
  display_py_remark(['Dropping RN'' Temporary Tables:',nl]),
  display_py_drop_tables_list(Nodes,DBMS).

%
% display_py_drop_tables_list(+Nodes,+DBMS)
% 
% display_py_drop_temp_views(Nodes,DBMS) :-
%   display_py_remark(['Dropping Temp Views:',nl]),
%   display_py_drop_views_list(Nodes,DBMS).

display_py_drop_tables_list([],_DBMS).
display_py_drop_tables_list([(RelName/_Arity)|Nodes],DBMS) :-
  write_log_list(
    ['cursor.execute("','$exec'(display_drop_table(RelName,DBMS)),'")',nl]),
  display_py_drop_tables_list(Nodes,DBMS).

%
% display_py_drop_temp_views(+Nodes,+DBMS)
% 
display_py_drop_temp_views(Nodes,_DBMS) :-
  (\+ ground(Nodes)
   ;
   Nodes==[]),
  !.
display_py_drop_temp_views(Nodes,DBMS) :-
  display_py_remark(['Dropping Temp Views:',nl]),
  display_py_drop_views_list(Nodes,DBMS).

display_py_drop_views_list([],_DBMS).
display_py_drop_views_list([(RelName/_Arity)|Nodes],DBMS) :-
  write_log_list(
    ['cursor.execute("','$exec'(display_drop_view(RelName,DBMS)),'")',nl]),
  display_py_drop_views_list(Nodes,DBMS).

%
% display_py_commit
% 
display_py_commit :-
  nl_log,
  display_py_remark(['Commit changes:',nl]),
  write_log_list(['conn.commit()',nl,nl]).
  
  
%
% display_py_success
% 
display_py_success :-
  display_py_remark(['If successful, print Success:',nl]),
  write_log_list(['print("Success.")',nl]).
  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% In/Out Algorithm
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  
in_out_sql_list(RNiSQLsts,I,Strata,InRNSQLsts,OutRNSQLsts) :-
  in_out_sql_list(RNiSQLsts,I,Strata,[],InRNSQLsts,[],OutRNSQLsts).
  
in_out_sql_list([],_I,_Strata,InRNSQLsts,InRNSQLsts,OutRNSQLsts,OutRNSQLsts).
in_out_sql_list([(RNi,SQLst)|RNiSQLsts],I,Strata,InRNSQLstsI,InRNSQLstsO,OutRNSQLstsI,OutRNSQLstsO) :-
  in_out_sql(SQLst,I,Strata,InSQLstI1,OutSQLstI1),
  in_out_glue(InRNSQLstsI,(RNi,InSQLstI1),InRNSQLstsI1),
  in_out_glue(OutRNSQLstsI,(RNi,OutSQLstI1),OutRNSQLstsI1),
  in_out_sql_list(RNiSQLsts,I,Strata,InRNSQLstsI1,InRNSQLstsO,OutRNSQLstsI1,OutRNSQLstsO).

in_out_glue(Xs,(_,'$empty'),Xs) :-
  !.
in_out_glue(Xs,X,[X|Xs]).
  
in_out_sql((SQLst,_),I,Strata,InSQLst,OutSQLst) :-
  in_out_sql(SQLst,I,Strata,InSQLst,OutSQLst).
in_out_sql(SQLst,I,Strata,'$empty',SQLst) :-
  str(SQLst,Strata,Str),
  Str<I,
  !.
in_out_sql(union(D,SQLst1,SQLst2),I,Strata,InSQLst,OutSQLst) :-
  !,
  in_out_sql(SQLst1,I,Strata,InSQLst1,OutSQLst1),
  in_out_sql(SQLst2,I,Strata,InSQLst2,OutSQLst2),
  str(SQLst1,Strata,St1),
  str(SQLst2,Strata,St2),
  (St1==St2 % == I
   ->
    build_set_sql(union,D,InSQLst1,InSQLst2,InSQLst),
    build_set_sql(union,D,OutSQLst1,OutSQLst2,OutSQLst)
   ;
    (St1==I,
     St2< I
     ->
      InSQLst=InSQLst1,
      build_set_sql(union,D,OutSQLst1,SQLst2,OutSQLst)
     ;
      % St1<i , St2=i
      InSQLst=InSQLst2,
      build_set_sql(union,D,SQLst1,OutSQLst2,OutSQLst)
    )    
  ).
in_out_sql(except(D,SQLst1,SQLst2),I,Strata,InSQLst,OutSQLst) :-
  !,
  in_out_sql(SQLst1,I,Strata,InSQLst1,OutSQLst1),
  build_set_sql(except,D,InSQLst1,SQLst2,InSQLst),
  build_set_sql(except,D,OutSQLst1,SQLst2,OutSQLst).
in_out_sql(SQLst,_I,_Strata,SQLst,'$empty'). % select

build_set_sql(_SetOp,_D,SQLst,'$empty',SQLst) :-
  !.
build_set_sql(_SetOp,_D,'$empty',SQLst,SQLst) :-
  !.
build_set_sql(SetOp,D,SQLst1,SQLst2,SQLst) :-
  SQLst=..[SetOp,D,SQLst1,SQLst2].

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% str Function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

str(SQLst,St) :-
  rel_strata(Strata),
  str(SQLst,Strata,St).
  
str((SQLst,_),Strata,St) :-
  !,
  str(SQLst,Strata,St).
str(SQLst,Strata,St) :-
  rn_query((SQLst,_),RNs),
  str_rel_list(RNs,Strata,Sts),
  my_list_max(Sts,0,St).
  
str_rel_list([],_Strata,[]).
str_rel_list([RN|RNs],Strata,[St|Sts]) :-
  str_rel(RN,Strata,St),
  str_rel_list(RNs,Strata,Sts).

str_rel(dual,_Strata,0) :-
  !.
str_rel(RN,Strata,St) :-
  member((RN,St),Strata).
  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Execute the Python Script
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

execute_py_script(FileName,Status) :-
  atom_concat_list([python,' ',FileName],Process),
  my_shell(Process,sync,Status).
  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% SQL-Related Stuff
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
display_create_table(RelName,normal,DBMS) :-
  display_create_clause_table(RelName,'',DBMS).
% display_create_table(RelName,temp,DBMS) :-
%   memberchk(DBMS,[db2,oracle,sqlanywhere]),
%   !,
%   display_create_clause_table(RelName,'LOCAL TEMPORARY ',DBMS).
% display_create_table(RelName,temp,DBMS) :-
%   memberchk(DBMS,[sqlanywhere]),
%   !,
%   display_create_clause_table(RelName,'GLOBAL TEMPORARY ',DBMS).
display_create_table(RelName,temp,DBMS) :-
  create_temp_table_clause(DBMS,TempClause),
  display_create_clause_table(RelName,TempClause,DBMS).
  
display_create_clause_table(RelName,TClause,DBMS) :-
  write_log_list(['CREATE ',TClause,'TABLE ',RelName,'(']),
  get_table_typed_arguments(RelName,ColnameTypes),
  display_schema_typed_cols_sequence(ColnameTypes,[],DBMS),
  write_log_list([');']).
  
display_schema_typed_cols_sequence([C:T],Ctrs,DBMS) :-
  internal_type_RDBMS_type(T,DBMS,RT),
  delimited_system_identifier(C,DBMS,DC),
  (column_ctr(C,Ctrs,Ctr)
   ->
    L=[DC,' ',RT,' ',Ctr]
   ;
    L=[DC,' ',RT]),
  write_log_list(L).
display_schema_typed_cols_sequence([C:T,CT1|CTs],Ctrs,DBMS) :-
  display_schema_typed_cols_sequence([C:T],Ctrs,DBMS),
  write_log(', '),
  display_schema_typed_cols_sequence([CT1|CTs],Ctrs,DBMS).
  
delimited_system_identifier(C,DBMS,DC) :-
  is_system_identifier(C),
  !,
  delimited_dbms_sql_identifier(C,DBMS,SC),
  py_escape_double_quotes(SC,DBMS,DC).
delimited_system_identifier(C,_DBMS,C).

py_escape_double_quotes(SC,DBMS,DC) :-
  (my_sql_left_quotation_mark("""",DBMS) 
   -> 
    atom_codes(SC,StrSC),
    escape_double_quotes_str(StrSC,StrDC),
    atom_codes(DC,StrDC)
   ;
    DC=SC).
 
escape_double_quotes_str(StrSC,StrDC) :-
  replace_all_string(StrSC,"""","\\""",StrDC).
 
delimited_system_identifier_list([],_DBMS,[]).
delimited_system_identifier_list([X|Xs],DBMS,[Y|Ys]) :-
  delimited_system_identifier(X,DBMS,Y),
  delimited_system_identifier_list(Xs,DBMS,Ys).


column_ctr(C,Ctrs,'NOT NULL') :-
  memberchk(not_nullables(Cs),Ctrs),
  memberchk(C,Cs).
  
display_sequence([C]) :-
  write_log(C).
display_sequence([C,C1|Cs]) :-
  display_sequence([C]),
  write_log(', '),
  display_sequence([C1|Cs]).
  
display_create_view(Schema,Query,DBMS) :-
  DBMS==access,
  !,
  functor(Schema,ViewName,_Arity),
  write_log_list(['CREATE VIEW ',ViewName,' AS ','$exec'(write_sql(Query,0,DBMS))]).
display_create_view(Schema,Query,DBMS) :-
  write_log_list(['CREATE VIEW ',Schema,' AS ','$exec'(write_sql(Query,0,DBMS))]).

display_py_create_view_list([],_DBMS).
display_py_create_view_list([create_view(_Lang,SQLst,Schema)|RelDefs],DBMS) :-
  write_log_list(['cursor.execute("', '$exec'(display_create_view(Schema,SQLst,DBMS)), '")',nl]),
  display_py_create_view_list(RelDefs,DBMS).

display_drop_table(RelName,DBMS) :-
  my_odbc_dbms_relation_name(DBMS,RelName,ODBCRelName),
  write_log_list(['DROP TABLE ',ODBCRelName,';']).
  
display_drop_view(RelName,DBMS) :-
  my_odbc_dbms_relation_name(DBMS,RelName,ODBCRelName),
  (DBMS==access -> Object='TABLE' ; Object='VIEW'),
  write_log_list(['DROP ',Object,' ',ODBCRelName,';']).
  
display_insert_into(Schema,SQLst,access) :-
  !,
  functor(Schema,Rel,_),
  display_insert_into(Rel,SQLst,standard).
display_insert_into(Schema,SQLst,DBMS) :-
  DBMS==mysql,
  !,
  %reset_alias_id,
  select_from_sqlst(SQLst,DBMS,ISQLst),
  py_untyped_schema_to_delimited_schema(Schema,DBMS,DSchema),
  write_log_list(['INSERT INTO ',DSchema,' ','$exec'(write_sql(ISQLst,0,DBMS))]).
display_insert_into(Schema,SQLst,DBMS) :-
  py_untyped_schema_to_delimited_schema(Schema,DBMS,DSchema),
  write_log_list(['INSERT INTO ',DSchema,' ','$exec'(write_sql(SQLst,0,DBMS))]).

py_untyped_schema_to_delimited_schema(Schema,DBMS,DSchema) :-
  untyped_schema_to_delimited_schema(Schema,DBMS,DNSSchema),
  DNSSchema=..[Rel|Colnames],
  delimited_system_identifier_list(Colnames,DBMS,DColnames),
  DSchema=..[Rel|DColnames].


display_delete_from(Schema,SQLst,DBMS) :-
  DBMS==mysql,
  !,
  %reset_alias_id,
  select_from_sqlst(SQLst,DBMS,DSQLst),
  Schema=..[Name|Args],
  write_log_list(['DELETE FROM ',Name,' ','$exec'(write_sql_cond('WHERE ',in(Args,DSQLst),0,DBMS))]).
display_delete_from(Schema,SQLst,DBMS) :-
  Schema=..[Name|Args],
  write_log_list(['DELETE FROM ',Name,' ','$exec'(write_sql_cond('WHERE ',in(Args,SQLst),0,DBMS))]).

  
replace_except(RelName,(SQLst,AS),RelDefs,Ns,(RSQLst,AS)) :-
  !,
  replace_except(RelName,SQLst,RelDefs,Ns,RSQLst).
replace_except(RelName,union(D,SQLst1,SQLst2),RelDefs,Ns,union(D,RSQLst1,RSQLst2)) :-
  !,
  replace_except(RelName,SQLst1,RelDefs1,Ns1,RSQLst1),
  replace_except(RelName,SQLst2,RelDefs2,Ns2,RSQLst2),
  append(RelDefs1,RelDefs2,RelDefs),
  append(Ns2,Ns1,Ns).
replace_except(RelName,except(_D,SQLst1,SQLst2),RelDefs,Ns,RSQLst) :-
  !,
  replace_except(RelName,SQLst1,RelDefs1,Ns1,RSQLst1),
  replace_except(RelName,SQLst2,RelDefs2,Ns2,RSQLst2),
  atom_concat(RelName,'_temp',RelTemp),
  new_relation_name(RelTemp,RenName),
  get_table_untyped_schema(RelName,Schema),
  rename_relation_schema(Schema,RenName,RenSchema),
  get_table_untyped_arguments(RelName,Colnames),
  correlate(Colnames,RSQLst2,RenName,RSQLst),
  concat_lists([RelDefs2,RelDefs1,[create_view(sql,RSQLst1,RenSchema)]],RelDefs),
  append([(RenName/_)|Ns1],Ns2,Ns).
replace_except(_RelName,SQLst,[],[],SQLst).

% extract_insert_delete(union(D,SQLst1,SQLst2),ISQLst,DSQLst) :-
%   !,
%   extract_insert_delete(SQLst1,ISQLst1,DSQLst1),
%   extract_insert_delete(SQLst2,ISQLst2,DSQLst2),
%   union_glue(D,ISQLst1,ISQLst2,ISQLst),
%   union_glue(D,DSQLst1,DSQLst2,DSQLst).
% extract_insert_delete(except(D,SQLst1,SQLst2),ISQLst1,DSQLst) :-
%   !,
%   extract_insert_delete(SQLst1,ISQLst1,DSQLst1),
%   (DSQLst1=='$empty'
%    ->
%     DSQLst=SQLst2
%    ;
%     DSQLst=union(D,DSQLst1,SQLst2)).
% extract_insert_delete(SQLst,SQLst,'$empty').

% union_glue(_D,'$empty',S,S) :-
%   !.
% union_glue(_D,S,'$empty',S) :-
%   !.
% union_glue(D,S1,S2,union(D,S1,S2)).


display_relation_contents(Rs) :-
  hrsql_connection(Connection),
  processC(use_db,[Connection],[],_),
  display_relation_content_list(Rs,Connection),
  processC(use_ddb,[],[],_).
  
display_relation_content_list([],_Connection).
display_relation_content_list([(R/_)|Rs],Connection) :-
  display_relation_content(R,Connection),
  display_relation_content_list(Rs,Connection).
  
display_relation_content(R,Connection) :-
  my_odbc_identifier_name(Connection,R,ODBCR),
  atom_codes(ODBCR,RStr),
  get_table_typed_schema(R,Schema),
  schema_to_colnames(Schema,Colnames),
  opened_db(Connection,_,DBMS),
  delimited_dbms_sql_identifier_list(Colnames,DBMS,DColnames),
  xfy_connect_with(DColnames,',',TCols),
  my_term_to_string_unquoted(TCols,ColsStr),
  concat_lists(["SELECT * FROM ",RStr," ORDER BY ",ColsStr],QueryStr),
  my_odbc_dql_query_wo_schema(QueryStr,Rows),
%  get_tuples_in_relation_error(ODBCR,Rows),
%  write_info_log(['Relation ',R,': ',Rows]),
  write_info_log(['Relation ',R,':']),
  display_bag(Rows),
  (display_nbr_of_tuples(on) -> display_nbr_of_tuples(Rows,computed,_Error) ; true).
  
% get_tuples_in_relation_error(R,Tuples) :-
%   get_tuples_in_relation(R,Tuples),
%   !.
% get_tuples_in_relation_error(_R,'*** ERROR ***').
  
create_temp_table_clause(DBMS,'') :-
  memberchk(DBMS,[mysql]),
  !.
create_temp_table_clause(DBMS,'LOCAL TEMPORARY ') :-
  memberchk(DBMS,[sqlanywhere]),
  !.
create_temp_table_clause(DBMS,'GLOBAL TEMPORARY ') :-
  memberchk(DBMS,[db2,oracle]),
  !.
create_temp_table_clause(DBMS,'') :-
  memberchk(DBMS,[access]),
  !.
create_temp_table_clause(_DBMS,'TEMPORARY ').

dbms_without_except(mysql).
dbms_without_except(access).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Ancillary Python Stuff
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% display_py_try_except(+Try,+Except)
%
% Display a try - except block. Each line in the lists (Try/Except, ended with nl) are indented
%
display_py_try_except(Try,Except) :-
  write_log_list(['try:',nl]),
  display_py_indent(Try),
  write_log_list(['except:',nl]),
  display_py_indent(Except).

%
% display_py_try_pass(+Try)
%
% Display a try - except block, where the except part is assumed to be 'pass' (do nothing)
%
display_py_try_pass(Try) :-
  display_py_try_except(Try,[pass,nl]).
  
%
% display_py_remark(+Remark)
%
% Remark each Python line (terminated with 'nl' in the input list)
%
display_py_remark(Remark) :-
  prepend_py_lines(Remark,'# ',PRemark),
  write_log_list(PRemark).
 
%
% display_py_indent(+What)
%
% Display indented each Python line (terminated with 'nl' in the input list)
%
display_py_indent(What) :-
  prepend_py_lines(What,'  ',PWhat),
  write_log_list(PWhat).
 
% 
% indent_py(+Ls,-ILs)  
%
% Indent each Python line (terminated with 'nl' in the input list)
% The first atom in the line is indented
indent_py(Ls,ILs) :-
  prepend_py_lines(Ls,'  ',ILs).

% 
% prepend_py_lines(+Ls,+Atom,-ILs)  
%
% Prepend Atom to each Python line (terminated with 'nl' in the input list)
% The first atom in the line is the one to be prepended
prepend_py_lines([],_,[]).
prepend_py_lines(Ls,P,ILs) :-
  append([X|Xs],[nl|TLs],Ls),
  atom_concat(P,X,IX),
  prepend_py_lines(TLs,P,ITLs),
  append([IX|Xs],[nl|ITLs],ILs).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Help on Commands
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

display_hrsql_help :-
  write_log('- HR-SQL Commands ---------------------------------------'), nl_log,
  write_log('                                                         '), nl_log,
  write_log(' /process_db <db_file> : Load and process a database     '), nl_log,
  write_log(' /load_db <db_file>    : Load a database                 '), nl_log,
  write_log(' /process_db           : Process the loaded database     '), nl_log,
  write_log(' /transform_db         : Transform HR-SQL to R-SQL DB    '), nl_log,
  write_log(' /hrsql Connection     : Select an ODBC connection       '), nl_log,
  write_log(' /list_relations       : List the relations              '), nl_log,
  write_log(' /pdg                  : Display the dependency graph    '), nl_log,
  write_log(' /strata               : Display the strata              '), nl_log,
  write_log(' /help                 : Show this help                  '), nl_log,
  write_log(' /quit                 : End system session              '), nl_log,
  write_log('                                                         '), nl_log,
  write_log(' Other inputs are processed as SQL queries               '), nl_log,
  write_log('---------------------------------------------------------'), nl_log, nl_log.

  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Informative banner
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

display_hrsql_banner :-
  display_banner(off),
  !.
display_hrsql_banner :-
  hrsql_version(V),
  write_log('*********************************************************'), nl_log,
  write_log('*                                                       *'), nl_log,
  write_log('*    HR-SQL '), write_log(V), write_log(': A Hypothetical and Recursive           *'), nl_log,
  write_log('*                Framework for SQL Databases            *'), nl_log,
  write_log('*                                                       *'), nl_log,
  write_log('*                                      Susana Nieva (1) *'), nl_log,
  write_log('*                             Fernando Saenz-Perez  (2) *'), nl_log,
  write_log('*                           Jaime Sanchez-Hernandez (1) *'), nl_log,
  write_log('*                              UCM GPD (1)DSIC (2)DISIA *'), nl_log,
  write_log('*                                                       *'), nl_log,
  write_log('* This program comes with ABSOLUTELY NO WARRANTY, is    *'), nl_log,
  write_log('* free software, and you are welcome to redistribute it *'), nl_log,
  write_log('* under certain conditions. Type "/license" for details *'), nl_log,
  write_log('*********************************************************'), nl_log, nl_log.

  
